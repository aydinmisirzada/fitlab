#!/usr/bin/env bash
export COSMOSDB_URI=https://dbfitlab.documents.azure.com:443/
export COSMOSDB_KEY=AX09hOpjJqwZgPC5QIKM0tlHfntl9QKvR847sZUaQjA0WP8LpbyjbTTC2NScSTe4NbEytCiQyS4V6aX56T2tFQ==
export COSMOSDB_DBNAME=dbfitlab