package fitlab.Data.Model;

public enum Semester {
    SUMMER,
    WINTER;
}
