package fitlab.Data.Model;

public enum Role {
    USER,
    ADMIN;
}
