package fitlab.Data.Model;

public enum ContentType {
    HOMEWORK,
    TEST,
    EXAM
}
